package aa.bb;

public class Hello_$World {

	public static void main(String[] args) {
		System.out.println("�ݰ����ϴ�.");
	}

}
