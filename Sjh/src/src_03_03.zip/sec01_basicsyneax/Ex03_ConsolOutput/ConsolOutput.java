package sec01_basicsyneax.Ex03_ConsolOutput;

public class ConsolOutput {

	public static void main(String[] args) {
	
		//���� P51 Page �ǽ� 

	}

}
