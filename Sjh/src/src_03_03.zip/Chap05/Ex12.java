package Chap05;

public class Ex12 {

}
