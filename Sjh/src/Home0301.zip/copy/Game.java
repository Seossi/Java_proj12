package Home0301.copy;

public class Game {

	public static void main(String[] args) {
		
		
	System.out.println("=============== 369 ���� =============");

	
	
			
	int i;
	for(i=0;i<100;i++){

	if((i==3||i==6||i==9)||((i%10==3||i%10==6||i%10==9)&&(i/10!=3&&i/10!=6&&i/10!=9))|| ((i/10==3||i/10==6||i/10==9)&&(i%10!=3&&i%10!=6&&i%10!=9))){
	System.out.println(i + " ¦!!"); 
	}
	else if((i%10==3||i%10==6||i%10==9)&&(i/10==3||i/10==6||i/10==9)){	
	System.out.println(i + "¦!! ¦!!");

	
	
	}
	
		
	}
	}	
}   

